(function ($ngApp, app, callback) {
	callback();
})