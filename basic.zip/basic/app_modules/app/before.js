(function ($ngApp, _, callback) {
	callback();
})