﻿(function ($scope) {
	$scope.hello = 'world @ ' + new Date();
})